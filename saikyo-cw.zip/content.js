(function(){"use strict";const T="plugin_";async function ue(){const e=await chrome.storage.sync.get(null),n={};for(const[t,o]of Object.entries(e))t.startsWith(T)&&(n[t.replace(T,"")]=o);return n}async function ee(e){var o;const n=`${T}${e}`;return(o=(await chrome.storage.sync.get(n))[n])==null?void 0:o.config}async function me(e,n){const t=`${T}${e}`,o=(await chrome.storage.sync.get(t))[t]??{};await chrome.storage.sync.set({[t]:{...o,config:n}})}function pe(e){return`${T}${e}`}function D(e,n,t=document.body){var r,s;const o=new WeakSet,c=i=>{o.has(i)||(o.add(i),n(i))};(s=(r=t.querySelectorAll)==null?void 0:r.call(t,e))==null||s.forEach(c);const a=new MutationObserver(i=>{var d,h,y;for(const p of i)for(const u of p.addedNodes){if(u.nodeType!==Node.ELEMENT_NODE)continue;const l=u;(d=l.matches)!=null&&d.call(l,e)&&c(l),(y=(h=l.querySelectorAll)==null?void 0:h.call(l,e))==null||y.forEach(c)}});return a.observe(t,{childList:!0,subtree:!0}),a}const te=[{id:"info",label:"info",description:"infoタグで囲む",type:"tag",defaultEnabled:!0},{id:"title",label:"title",description:"titleタグで囲む",type:"tag",defaultEnabled:!0},{id:"code",label:"code",description:"codeタグで囲む",type:"tag",defaultEnabled:!0},{id:"hr",label:"hr",description:"hrタグを挿入",type:"tag",defaultEnabled:!0},{id:"bow",label:"🙇",description:"おじぎ (bow)",type:"emo",defaultEnabled:!0},{id:"roger",label:"👌",description:"了解 (roger)",type:"emo",defaultEnabled:!0},{id:"cracker",label:"🎉",description:"クラッカー (cracker)",type:"emo",defaultEnabled:!0},{id:"clap",label:"👏",description:"拍手 (clap)",type:"emo",defaultEnabled:!1},{id:"congrats",label:"㊗️",description:"おめでとう (congrats)",type:"emo",defaultEnabled:!1},{id:"love",label:"❤️",description:"ハート (love)",type:"emo",defaultEnabled:!1},{id:"to-all",label:"@all",description:"全員にTO",type:"action",defaultEnabled:!0}];function ge(){return te.filter(e=>e.defaultEnabled).map(e=>e.id)}function ne(e,n){var a;const t=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,o=(a=Object.getOwnPropertyDescriptor(t,"value"))==null?void 0:a.set;if(!o)throw new Error("Cannot find native value setter");o.call(e,n);const c=e._valueTracker;c&&c.setValue(""),e.dispatchEvent(new Event("input",{bubbles:!0}))}function x(e,n){const t=e.selectionStart??e.value.length,o=e.selectionEnd??e.value.length,c=e.value.substring(0,t),a=e.value.substring(o);ne(e,c+n+a);const r=t+n.length;e.setSelectionRange(r,r)}function G(e,n,t){const o=e.selectionStart??e.value.length,c=e.selectionEnd??e.value.length,a=e.value.substring(0,o),r=e.value.substring(o,c),s=e.value.substring(c);ne(e,a+n+r+t+s);const i=o+n.length+r.length;e.setSelectionRange(i,i)}function fe(){const e=document.querySelector("#_to");e&&(e.click(),setTimeout(()=>{document.querySelectorAll('#_toList input[type="checkbox"]:not(:checked)').forEach(t=>t.click())},200))}const be={info:e=>G(e,"[info]","[/info]"),title:e=>G(e,"[info][title]","[/title][/info]"),code:e=>G(e,"[code]","[/code]"),hr:e=>x(e,"[hr]"),bow:e=>x(e,"(bow)"),roger:e=>x(e,"(roger)"),cracker:e=>x(e,"(cracker)"),clap:e=>x(e,"(clap)"),congrats:e=>x(e,"(congrats)"),love:e=>x(e,"(love)"),"to-all":()=>fe()};function ye(e){return be[e]}const F="scw-input-tools-style",P="scw-input-tools-icons",U="scw-input-tools__icon",Y="scw-input-tools__tag",W="scw-input-tools__emo",V="scw-input-tools__action",he=`
  #${P} {
    display: flex;
    align-items: center;
  }

  .${U} {
    align-items: center;
    cursor: pointer;
    display: flex;
    height: 24px;
    opacity: 0.8;
    margin: 0 4px;
  }

  .${U}:hover {
    opacity: 1;
  }

  .${Y},
  .${W},
  .${V} {
    -webkit-user-select: none;
    user-select: none;
    align-items: center;
    border-radius: 2px;
    color: #ffffff;
    display: flex;
    font-family: -apple-system, BlinkMacSystemFont, ".SFNSDisplay-Regular",
                 "Helvetica Neue", "Hiragino Sans", "ヒラギノ角ゴシック",
                 Meiryo, "メイリオ", sans-serif;
    font-size: 12px;
    line-height: 12px;
    padding: 2px 4px;
  }

  .${Y} { background-color: #444444; }
  .${W} { background-color: #ffa000; }
  .${V} { background-color: #5c8a8a; }
`;function ke(){if(document.getElementById(F))return;const e=document.createElement("style");e.id=F,e.textContent=he,document.head.appendChild(e)}function we(){return document.querySelector("#_chatText")}async function xe(){if(document.getElementById(P))return;const e=document.querySelector("#_emoticon");if(!e)return;const n=e.closest("ul");if(!n)return;const t=await ee("input-tools"),o=(t==null?void 0:t.enabledButtons)??ge(),c=new Set(o),a=te.filter(s=>c.has(s.id));if(a.length===0)return;ke();const r=document.createElement("ul");r.id=P;for(const s of a){const i=ye(s.id);if(!i)continue;const d=document.createElement("li");d.className=`_showDescription ${U}`,d.setAttribute("role","button"),d.setAttribute("aria-label",s.description);const h=s.type==="tag"?Y:s.type==="emo"?W:V,y=document.createElement("span");y.className=h,y.textContent=s.label,d.appendChild(y),d.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation();const u=we();u&&(u.focus(),i(u))}),r.appendChild(d)}n.insertAdjacentElement("afterend",r)}function ve(){var e,n;(e=document.getElementById(P))==null||e.remove(),(n=document.getElementById(F))==null||n.remove()}let _=null;const Ee={config:{id:"input-tools",name:"Input Tools",description:"コードブロック・絵文字・装飾タグの挿入、TO全選択"},init(){_=D("#_emoticon",()=>{xe()})},destroy(){_==null||_.disconnect(),_=null,ve()}};function oe(e,n=5e3){return new Promise((t,o)=>{const c=document.querySelector(e);if(c)return t(c);const a=new MutationObserver(()=>{const r=document.querySelector(e);r&&(a.disconnect(),t(r))});a.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{a.disconnect(),o(new Error(`Timeout waiting for: ${e}`))},n)})}function k(e){return new Promise(n=>setTimeout(n,e))}const K="scw-mute-button-style",g="scw-mute-button",E="scw-mute-button--active";let f=null,X=!1;const $e=`
  .${g} {
    position: fixed;
    bottom: 16px;
    right: 16px;
    z-index: 10000;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: none;
    background: #4c566a;
    color: white;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    transition: background 0.2s;
  }

  .${g}:hover { background: #5c6678; }

  .${g}.${E} { background: #bf616a; }
  .${g}.${E}:hover { background: #cf717a; }

  body.mainContentArea--dark .${g},
  body[data-theme="dark"] .${g},
  .darkMode .${g} {
    background: #5c6678;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
  }
  body.mainContentArea--dark .${g}:hover,
  body[data-theme="dark"] .${g}:hover,
  .darkMode .${g}:hover { background: #6c768a; }

  body.mainContentArea--dark .${g}.${E},
  body[data-theme="dark"] .${g}.${E},
  .darkMode .${g}.${E} { background: #bf616a; }
`;async function Se(){var e;if(!X){X=!0;try{const n=document.querySelector('[data-testid="room-header_room-settings-button"]');if(!n)throw new Error("設定ボタンが見つかりません");n.click(),await k(300),(await oe('[data-testid="room-header_room-settings_room-settings-menu"]',3e3)).click(),await k(500);const o=document.querySelectorAll('[role="tab"]');let c=null;for(const i of o)if(((e=i.textContent)==null?void 0:e.trim())==="ミュート"){c=i;break}if(!c)throw new Error("ミュートタブが見つかりません");c.click(),await k(300);const a=await oe("#_roomSettingMute",3e3);a.click(),await k(200);const r=document.querySelector('[data-testid="room-setting-dialog_save-button"]');if(!r)throw new Error("保存ボタンが見つかりません");r.click();const s=a.checked;f&&(f.textContent=s?"🔇":"🔔",f.classList.toggle(E,s),f.title=s?"ミュート中（クリックで解除）":"ミュートする")}catch(n){console.error("[saikyo-cw] Mute error:",n);const t=document.querySelector('.dialogContainer button[aria-label="閉じる"]');t==null||t.click()}finally{X=!1}}}function Ce(){if(document.getElementById(K))return;const e=document.createElement("style");e.id=K,e.textContent=$e,document.head.appendChild(e)}const Te={config:{id:"mute-button",name:"Mute Button",description:"ワンクリックでチャットをミュート"},init(){Ce(),f=document.createElement("button"),f.className=g,f.title="ミュートする",f.textContent="🔔",f.addEventListener("click",Se),document.body.appendChild(f)},destroy(){var e;f==null||f.remove(),f=null,(e=document.getElementById(K))==null||e.remove()}},_e={MESSAGE_ACTION_NAV:".messageActionNav"},Q="https://www.chatwork.com/",re="quick-task",ce="__scw_quick_task";async function ae(){return await ee(re)??{}}async function Ae(){var o;const e=await ae();if(e.myChatId)return e.myChatId;const n=prompt("taskを投稿するチャットのID(#!rid1234の1234の部分)");if(!n)throw new Error("Room ID is required");const t=((o=n.match(/\d+/))==null?void 0:o[0])??n;return await me(re,{...e,myChatId:t}),t}function Ie(e){return e.closest("._message")}function Le(e){const n=e.getAttribute("data-rid")??"",t=e.getAttribute("data-mid")??"";return`${Q}#!rid${n}-${t}`}function Me(e){const n=e.querySelectorAll("pre span");return Array.from(n).map(t=>t.innerText).join(`
`)}async function Be(e,n){var c;const t=(c=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value"))==null?void 0:c.set;t&&t.call(e,n),e.value=n;const o=e._valueTracker;o&&o.setValue("hello"),await k(200),e.dispatchEvent(new Event("input",{bubbles:!0}))}async function Ne(){try{const e=new MouseEvent("mouseover",{bubbles:!0,cancelable:!0});document.querySelectorAll("#_taskInputActive button").forEach(o=>o.dispatchEvent(e)),await k(200);const t=document.querySelector(".floatingComponentContainer .userIconImage");t==null||t.click()}catch(e){console.warn("[saikyo-cw] assignToSelf:",e)}await k(200)}async function qe(e,n){const t=Le(e),o=n==="mychat-message"||n==="here-message",c=n==="here-url"||n==="here-message",a=o?`${t}
${Me(e)}`:t;if(c){const d=e.getAttribute("data-rid")??"";location.href=`${Q}#!rid${d}`}else{const d=await Ae();location.href=`${Q}#!rid${d}`}await k(200);const r=document.querySelector("#_taskAddArea");r==null||r.click(),await k(200);const s=document.querySelector("#_taskInputActive textarea");s&&await Be(s,a),c&&await Ne();const i=document.querySelector('button[data-testid="room-sub-column_room-task_add-button"]');i==null||i.click()}function De(e){if(e[ce])return;e[ce]=!0;const n=e.querySelectorAll(":scope > li"),t=Array.from(n).find(a=>{var r;return((r=a.textContent)==null?void 0:r.trim())==="タスク"});if(!t)return;const o=t.cloneNode(!0),c=o.querySelector(".actionLabel");c&&(c.textContent="my"),t.insertAdjacentElement("afterend",o),o.addEventListener("click",async()=>{const a=Ie(e);if(!a)return;const s=(await ae()).mode??"mychat-url";try{await qe(a,s)}catch(i){console.error("[saikyo-cw] Quick Task error:",i)}})}let A=null;const Pe={config:{id:"quick-task",name:"Quick Task",description:"メッセージにmy taskボタンを追加"},init(){A=D(_e.MESSAGE_ACTION_NAV,e=>{De(e)})},destroy(){A==null||A.disconnect(),A=null,document.querySelectorAll(".scw-quick-task__btn").forEach(e=>e.remove())}},J="scw-mention-group-style",$="scw-mention-group-btn",S="scw-mention-group-dropdown",I="scw-mention-group-toast",v="quickMentionGroups",O="scw-mg-add-to-group",m="scw-mg-add-dropdown",Oe=`
  #${$} {
    display: inline-block;
    width: 32px;
    height: 32px;
    padding: 8px;
    border: none;
    border-radius: 4px;
    background: transparent;
    color: currentColor;
    cursor: pointer;
    vertical-align: middle;
    transition: background 0.15s;
  }
  #${$}:hover {
    background: rgba(0, 0, 0, 0.08);
  }
  #${$} svg {
    display: block;
    width: 16px;
    height: 16px;
  }

  #${S} {
    position: fixed;
    z-index: 100000;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05);
    padding: 6px;
    min-width: 180px;
    max-width: 260px;
    animation: scw-mg-in 0.12s ease-out;
  }
  @keyframes scw-mg-in {
    from { opacity: 0; transform: translateY(-4px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  .scw-mg-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 9px 14px;
    border: none;
    border-radius: 6px;
    background: none;
    cursor: pointer;
    font-size: 13px;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
    color: #333;
    transition: background 0.1s;
    text-align: left;
  }
  .scw-mg-item:hover { background: #e8f0fe; }
  .scw-mg-item-name { font-weight: 500; }
  .scw-mg-item-count {
    font-size: 11px;
    color: #888;
    background: #f0f0f0;
    padding: 2px 8px;
    border-radius: 10px;
    margin-left: 8px;
  }

  .scw-mg-empty {
    padding: 12px 14px 4px;
    font-size: 12px;
    color: #999;
    text-align: center;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
  }
  .scw-mg-hint {
    padding: 2px 14px 12px;
    font-size: 11px;
    color: #bbb;
    text-align: center;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
  }

  #${I} {
    position: fixed;
    bottom: 80px;
    left: 50%;
    transform: translateX(-50%) translateY(6px);
    z-index: 100001;
    background: #333;
    color: #fff;
    padding: 8px 18px;
    border-radius: 20px;
    font-size: 13px;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    opacity: 0;
    transition: all 0.25s ease;
    pointer-events: none;
    white-space: nowrap;
  }
  #${I}.scw-mg-toast-show {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }

  /* ダークモード */
  body.mainContentArea--dark #${S},
  body[data-theme="dark"] #${S},
  .darkMode #${S} {
    background: #2a2a2a;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.08);
  }
  body.mainContentArea--dark .scw-mg-item,
  body[data-theme="dark"] .scw-mg-item,
  .darkMode .scw-mg-item { color: #ddd; }
  body.mainContentArea--dark .scw-mg-item:hover,
  body[data-theme="dark"] .scw-mg-item:hover,
  .darkMode .scw-mg-item:hover { background: #333; }
  body.mainContentArea--dark .scw-mg-item-count,
  body[data-theme="dark"] .scw-mg-item-count,
  .darkMode .scw-mg-item-count { background: #444; color: #aaa; }

  /* プロフィールカード「グループに追加」ボタン */
  .${O} {
    padding: 6px 12px;
    border: 1px solid #4a90d9;
    border-radius: 6px;
    background: #4a90d9;
    color: white;
    font-size: 12px;
    cursor: pointer;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
    transition: background 0.15s;
    position: relative;
  }
  .${O}:hover { background: #357abd; }

  .${m} {
    position: absolute;
    bottom: 100%;
    left: 0;
    z-index: 100002;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    padding: 4px;
    min-width: 160px;
    margin-bottom: 4px;
    animation: scw-mg-in 0.12s ease-out;
  }
  .${m} button {
    display: block;
    width: 100%;
    padding: 8px 12px;
    border: none;
    border-radius: 6px;
    background: none;
    cursor: pointer;
    font-size: 12px;
    text-align: left;
    color: #333;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
  }
  .${m} button:hover { background: #e8f0fe; }
  .${m} .scw-mg-add-new {
    color: #4a90d9;
    border-top: 1px solid #eee;
    margin-top: 2px;
    padding-top: 8px;
  }

  body.mainContentArea--dark .${m},
  body[data-theme="dark"] .${m},
  .darkMode .${m} { background: #2a2a2a; }
  body.mainContentArea--dark .${m} button,
  body[data-theme="dark"] .${m} button,
  .darkMode .${m} button { color: #ddd; }
  body.mainContentArea--dark .${m} button:hover,
  body[data-theme="dark"] .${m} button:hover,
  .darkMode .${m} button:hover { background: #333; }
`;function je(e){return e.map(n=>`[To:${n.accountId}]${n.name}さん`).join(`
`)}function Re(){return document.getElementById("_chatText")}function He(e){const n=Re();if(!n){L("チャット入力欄が見つかりません");return}const t=je(e),o=n.value,c=n.selectionStart||0,a=n.selectionEnd||0,r=o.substring(0,c),s=o.substring(a),i=t+`
`;n.value=r+i+s;const d=c+i.length;n.selectionStart=d,n.selectionEnd=d,n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0})),n.focus(),L(`${e.length}人にメンション追加`)}function L(e){const n=document.getElementById(I);n&&n.remove();const t=document.createElement("div");t.id=I,t.textContent=e,document.body.appendChild(t),requestAnimationFrame(()=>t.classList.add("scw-mg-toast-show")),setTimeout(()=>{t.classList.remove("scw-mg-toast-show"),setTimeout(()=>t.remove(),300)},2e3)}function j(){const e=document.getElementById(S);e&&e.remove()}function ze(e){j(),chrome.storage.sync.get(v,n=>{const t=n[v]||[],o=document.createElement("div");if(o.id=S,t.length===0){const i=document.createElement("div");i.className="scw-mg-empty",i.textContent="グループ未登録",o.appendChild(i);const d=document.createElement("div");d.className="scw-mg-hint",d.textContent="拡張機能アイコンから設定してください",o.appendChild(d)}else for(const i of t){const d=document.createElement("button");d.className="scw-mg-item",d.innerHTML=`<span class="scw-mg-item-name">${i.name}</span><span class="scw-mg-item-count">${i.members.length}人</span>`,d.addEventListener("click",h=>{h.preventDefault(),h.stopPropagation(),He(i.members),j()}),o.appendChild(d)}document.body.appendChild(o);const c=e.getBoundingClientRect(),a=o.getBoundingClientRect();let r=c.bottom+6,s=c.left;r+a.height>window.innerHeight-8&&(r=c.top-a.height-6),s+a.width>window.innerWidth-8&&(s=window.innerWidth-a.width-8),o.style.top=`${r}px`,o.style.left=`${s}px`,setTimeout(()=>{document.addEventListener("click",j,{once:!0})},10)})}function se(){if(document.getElementById(J))return;const e=document.createElement("style");e.id=J,e.textContent=Oe,document.head.appendChild(e)}function R(){if(document.getElementById($))return;const e=document.getElementById("_to"),n=document.getElementById("_emoticon"),t=e||n;if(!t)return;const o=t.closest("._showDescription");if(!(o!=null&&o.parentElement))return;se();const c=document.createElement("div");c.className="_showDescription",c.style.display="block";const a=document.createElement("div");a.style.display="inline-block";const r=document.createElement("button");r.id=$,r.setAttribute("aria-label","クイックメンション：登録メンバーに一括メンション"),r.innerHTML=`<svg viewBox="0 0 10 10" width="16" height="16" fill="currentColor" aria-hidden="true">
    <circle cx="3.2" cy="2.5" r="1.5"/>
    <path d="M0.5 7.5C0.5 5.8 1.7 5 3.2 5s2.7.8 2.7 2.5v.5H0.5z"/>
    <circle cx="7" cy="2.5" r="1.3"/>
    <path d="M4.8 7.5C4.8 5.8 5.8 5 7 5s2.2.8 2.2 2.5v.5H4.8z"/>
  </svg>`,r.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),ze(r)}),a.appendChild(r),c.appendChild(a),o.parentElement.insertBefore(c,o.nextSibling)}function Ge(e){var i;if(e.querySelector(`.${O}`))return;const n=e.querySelector("[data-aid]"),t=n==null?void 0:n.getAttribute("data-aid");if(!t)return;const o=e.querySelector('[data-testid="profile-popup_user-name"] span[class*="_nameAid"]'),c=((i=o==null?void 0:o.textContent)==null?void 0:i.trim())??"";if(!c)return;const a=e.querySelector(".sc-fjvvzt, .sc-JrDLc > div:first-child");if(!a)return;se();const r=document.createElement("div");r.style.cssText="display: inline-block; position: relative;";const s=document.createElement("button");s.className=O,s.textContent="グループに追加",s.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),document.querySelectorAll(`.${m}`).forEach(h=>h.remove()),chrome.storage.sync.get(v,h=>{const y=h[v]||[],p=document.createElement("div");if(p.className=m,y.length===0){const u=document.createElement("button");u.className="scw-mg-add-new",u.textContent="新規グループを作成",u.addEventListener("click",()=>{const l=prompt("グループ名を入力");if(!l)return;const N={name:l,members:[{accountId:t,name:c}]};chrome.storage.sync.set({[v]:[N]},()=>{L(`「${l}」に ${c} を追加しました`),p.remove()})}),p.appendChild(u)}else{for(const l of y){const N=l.members.some(Qe=>Qe.accountId===t),q=document.createElement("button");q.textContent=N?`${l.name} (追加済み)`:l.name,N&&(q.style.color="#999",q.style.cursor="default"),q.addEventListener("click",()=>{N||(l.members.push({accountId:t,name:c}),chrome.storage.sync.set({[v]:y},()=>{L(`「${l.name}」に ${c} を追加しました`),p.remove()}))}),p.appendChild(q)}const u=document.createElement("button");u.className="scw-mg-add-new",u.textContent="+ 新規グループに追加",u.addEventListener("click",()=>{const l=prompt("グループ名を入力");l&&(y.push({name:l,members:[{accountId:t,name:c}]}),chrome.storage.sync.set({[v]:y},()=>{L(`「${l}」に ${c} を追加しました`),p.remove()}))}),p.appendChild(u)}r.appendChild(p),setTimeout(()=>{const u=l=>{!p.contains(l.target)&&l.target!==s&&(p.remove(),document.removeEventListener("click",u))};document.addEventListener("click",u)},10)})}),r.appendChild(s),a.appendChild(r)}function Fe(){var t,o;const e=document.getElementById($),n=e==null?void 0:e.closest("._showDescription");n==null||n.remove(),j(),(t=document.getElementById(I))==null||t.remove(),(o=document.getElementById(J))==null||o.remove()}let C=null,M=null;const Ue={config:{id:"mention-group",name:"Mention Group",description:"グループメンションをワンクリックで挿入"},init(){C=new MutationObserver(()=>{document.getElementById("scw-mention-group-btn")||R()}),C.observe(document.body,{childList:!0,subtree:!0}),R(),setTimeout(R,1e3),setTimeout(R,3e3),M=D('[data-testid="profile-popup_profile-button"]',e=>{const n=e.closest("[data-aid]");n&&Ge(n)})},destroy(){C==null||C.disconnect(),C=null,M==null||M.disconnect(),M=null,Fe()}},H="scw-reaction-copy",b="scw-reaction-copy__button",w="scw-reaction-copy__button--to",Z="scw-reaction-copy-style";let B=null;const Ye=`
  .${H} {
    display: flex;
    gap: 4px;
    margin-bottom: 4px;
  }

  .${b} {
    padding: 4px;
    font-size: 12px;
    background-color: #eee;
    border: 1px solid #ccc;
    border-radius: 4px;
    cursor: pointer;
    color: #333;
  }

  .${b}:hover {
    background-color: #ddd;
  }

  .${w} {
    background-color: #e0f0ff;
    border-color: #a8d4f0;
    color: #1a6fa8;
  }

  .${w}:hover {
    background-color: #cce4f7;
  }

  /* ダークモード */
  body.mainContentArea--dark .${b},
  body[data-theme="dark"] .${b},
  .darkMode .${b} {
    background-color: #3a3a3a;
    border-color: #555;
    color: #ddd;
  }

  body.mainContentArea--dark .${b}:hover,
  body[data-theme="dark"] .${b}:hover,
  .darkMode .${b}:hover {
    background-color: #4a4a4a;
  }

  body.mainContentArea--dark .${w},
  body[data-theme="dark"] .${w},
  .darkMode .${w} {
    background-color: #1a3a50;
    border-color: #2a5a7a;
    color: #8ac4ea;
  }

  body.mainContentArea--dark .${w}:hover,
  body[data-theme="dark"] .${w}:hover,
  .darkMode .${w}:hover {
    background-color: #224a62;
  }

  @media (prefers-color-scheme: dark) {
    body.mainContentArea--dark .${b},
    body[data-theme="dark"] .${b},
    .darkMode .${b} {
      background-color: #3a3a3a;
      border-color: #555;
      color: #ddd;
    }
  }
`;function ie(e){const n=e.querySelectorAll("li.reactionUserListTooltip__item");return Array.from(n).map(t=>{var a,r,s;let o=((r=(a=t.querySelector(".reactionUserListTooltip__userName"))==null?void 0:a.textContent)==null?void 0:r.trim())??"";o=o.replace(/さん$/,"");const c=t.getAttribute("data-cwui-lt-value")??((s=t.querySelector("img[data-aid]"))==null?void 0:s.getAttribute("data-aid"))??null;return{name:o,accountId:c}})}function de(e,n){const t=e.textContent;navigator.clipboard.writeText(n).then(()=>{e.textContent="コピー済み",setTimeout(()=>{e.textContent=t},1e3)})}function We(e){if(e.querySelector(`.${H}`))return;const n=document.createElement("div");n.className=H;const t=document.createElement("button");t.className=b,t.textContent="コピー",t.addEventListener("click",()=>{const a=ie(e).map(r=>r.name).filter(Boolean).join(`
`);de(t,a)});const o=document.createElement("button");o.className=`${b} ${w}`,o.textContent="TO付きコピー",o.addEventListener("click",()=>{const a=ie(e).filter(r=>r.name).map(r=>r.accountId?`[To:${r.accountId}]${r.name}さん`:r.name).join(`
`);de(o,a)}),n.appendChild(t),n.appendChild(o),e.prepend(n)}function Ve(){if(document.getElementById(Z))return;const e=document.createElement("style");e.id=Z,e.textContent=Ye,document.head.appendChild(e)}function Ke(){var e;(e=document.getElementById(Z))==null||e.remove()}const le=[Ee,Te,Pe,Ue,{config:{id:"reaction-copy",name:"Reaction Copy",description:"リアクションしたユーザー一覧をコピー（TO付きも対応）"},init(){Ve(),B=D("#_reactionUserList",e=>{We(e)})},destroy(){B==null||B.disconnect(),B=null,Ke(),document.querySelectorAll(`.${H}`).forEach(e=>e.remove())}}],z=new Map;async function Xe(){var n;const e=await ue();for(const t of le)(((n=e[t.config.id])==null?void 0:n.enabled)??!0)&&(t.init(),z.set(t.config.id,t));chrome.storage.onChanged.addListener((t,o)=>{var c;if(o==="sync")for(const a of le){const r=pe(a.config.id),s=t[r];if(!s)continue;const i=z.has(a.config.id),d=((c=s.newValue)==null?void 0:c.enabled)??!0;i&&!d?(a.destroy(),z.delete(a.config.id)):!i&&d&&(a.init(),z.set(a.config.id,a))}})}Xe()})();
