(function(){"use strict";const I="plugin_";async function be(){const e=await chrome.storage.sync.get(null),t={};for(const[n,o]of Object.entries(e))n.startsWith(I)&&(t[n.replace(I,"")]=o);return t}async function ae(e){var o;const t=`${I}${e}`;return(o=(await chrome.storage.sync.get(t))[t])==null?void 0:o.config}async function ye(e,t){const n=`${I}${e}`,o=(await chrome.storage.sync.get(n))[n]??{};await chrome.storage.sync.set({[n]:{...o,config:t}})}function he(e){return`${I}${e}`}function R(e,t,n=document.body){var r,i;const o=new WeakSet,a=s=>{o.has(s)||(o.add(s),t(s))};(i=(r=n.querySelectorAll)==null?void 0:r.call(n,e))==null||i.forEach(a);const c=new MutationObserver(s=>{var d,y,E;for(const C of s)for(const v of C.addedNodes){if(v.nodeType!==Node.ELEMENT_NODE)continue;const h=v;(d=h.matches)!=null&&d.call(h,e)&&a(h),(E=(y=h.querySelectorAll)==null?void 0:y.call(h,e))==null||E.forEach(a)}});return c.observe(n,{childList:!0,subtree:!0}),c}const ce=[{id:"info",label:"info",description:"infoタグで囲む",type:"tag",defaultEnabled:!0},{id:"title",label:"title",description:"titleタグで囲む",type:"tag",defaultEnabled:!0},{id:"code",label:"code",description:"codeタグで囲む",type:"tag",defaultEnabled:!0},{id:"hr",label:"hr",description:"hrタグを挿入",type:"tag",defaultEnabled:!0},{id:"bow",label:"🙇",description:"おじぎ (bow)",type:"emo",defaultEnabled:!0},{id:"roger",label:"👌",description:"了解 (roger)",type:"emo",defaultEnabled:!0},{id:"cracker",label:"🎉",description:"クラッカー (cracker)",type:"emo",defaultEnabled:!0},{id:"clap",label:"👏",description:"拍手 (clap)",type:"emo",defaultEnabled:!1},{id:"congrats",label:"㊗️",description:"おめでとう (congrats)",type:"emo",defaultEnabled:!1},{id:"love",label:"❤️",description:"ハート (love)",type:"emo",defaultEnabled:!1},{id:"to-all",label:"@all",description:"全員にTO",type:"action",defaultEnabled:!0}];function ke(){return ce.filter(e=>e.defaultEnabled).map(e=>e.id)}function ie(e,t){var c;const n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,o=(c=Object.getOwnPropertyDescriptor(n,"value"))==null?void 0:c.set;if(!o)throw new Error("Cannot find native value setter");o.call(e,t);const a=e._valueTracker;a&&a.setValue(""),e.dispatchEvent(new Event("input",{bubbles:!0}))}function $(e,t){const n=e.selectionStart??e.value.length,o=e.selectionEnd??e.value.length,a=e.value.substring(0,n),c=e.value.substring(o);ie(e,a+t+c);const r=n+t.length;e.setSelectionRange(r,r)}function V(e,t,n){const o=e.selectionStart??e.value.length,a=e.selectionEnd??e.value.length,c=e.value.substring(0,o),r=e.value.substring(o,a),i=e.value.substring(a);ie(e,c+t+r+n+i);const s=o+t.length+r.length;e.setSelectionRange(s,s)}function we(){const e=document.querySelector("#_to");e&&(e.click(),setTimeout(()=>{document.querySelectorAll('#_toList input[type="checkbox"]:not(:checked)').forEach(n=>n.click())},200))}const xe={info:e=>V(e,"[info]","[/info]"),title:e=>V(e,"[info][title]","[/title][/info]"),code:e=>V(e,"[code]","[/code]"),hr:e=>$(e,"[hr]"),bow:e=>$(e,"(bow)"),roger:e=>$(e,"(roger)"),cracker:e=>$(e,"(cracker)"),clap:e=>$(e,"(clap)"),congrats:e=>$(e,"(congrats)"),love:e=>$(e,"(love)"),"to-all":()=>we()};function Ee(e){return xe[e]}const W="scw-input-tools-style",H="scw-input-tools-icons",K="scw-input-tools__icon",X="scw-input-tools__tag",Q="scw-input-tools__emo",J="scw-input-tools__action",ve=`
  #${H} {
    display: flex;
    align-items: center;
  }

  .${K} {
    align-items: center;
    cursor: pointer;
    display: flex;
    height: 24px;
    opacity: 0.8;
    margin: 0 4px;
  }

  .${K}:hover {
    opacity: 1;
  }

  .${X},
  .${Q},
  .${J} {
    -webkit-user-select: none;
    user-select: none;
    align-items: center;
    border-radius: 2px;
    color: #ffffff;
    display: flex;
    font-family: -apple-system, BlinkMacSystemFont, ".SFNSDisplay-Regular",
                 "Helvetica Neue", "Hiragino Sans", "ヒラギノ角ゴシック",
                 Meiryo, "メイリオ", sans-serif;
    font-size: 12px;
    line-height: 12px;
    padding: 2px 4px;
  }

  .${X} { background-color: #444444; }
  .${Q} { background-color: #ffa000; }
  .${J} { background-color: #5c8a8a; }
`;function $e(){if(document.getElementById(W))return;const e=document.createElement("style");e.id=W,e.textContent=ve,document.head.appendChild(e)}function Se(){return document.querySelector("#_chatText")}async function Ce(){if(document.getElementById(H))return;const e=document.querySelector("#_emoticon");if(!e)return;const t=e.closest("ul");if(!t)return;const n=await ae("input-tools"),o=(n==null?void 0:n.enabledButtons)??ke(),a=new Set(o),c=ce.filter(i=>a.has(i.id));if(c.length===0)return;$e();const r=document.createElement("ul");r.id=H;for(const i of c){const s=Ee(i.id);if(!s)continue;const d=document.createElement("li");d.className=`_showDescription ${K}`,d.setAttribute("role","button"),d.setAttribute("aria-label",i.description);const y=i.type==="tag"?X:i.type==="emo"?Q:J,E=document.createElement("span");E.className=y,E.textContent=i.label,d.appendChild(E),d.addEventListener("click",C=>{C.preventDefault(),C.stopPropagation();const v=Se();v&&(v.focus(),s(v))}),r.appendChild(d)}t.insertAdjacentElement("afterend",r)}function Te(){var e,t;(e=document.getElementById(H))==null||e.remove(),(t=document.getElementById(W))==null||t.remove()}let M=null;const Ae={config:{id:"input-tools",name:"Input Tools",description:"コードブロック・絵文字・装飾タグの挿入、TO全選択"},init(){M=R("#_emoticon",()=>{Ce()})},destroy(){M==null||M.disconnect(),M=null,Te()}};function se(e,t=5e3){return new Promise((n,o)=>{const a=document.querySelector(e);if(a)return n(a);const c=new MutationObserver(()=>{const r=document.querySelector(e);r&&(c.disconnect(),n(r))});c.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{c.disconnect(),o(new Error(`Timeout waiting for: ${e}`))},t)})}function w(e){return new Promise(t=>setTimeout(t,e))}const Z="scw-mute-button-style",m="scw-mute-button",T="scw-mute-button--active";let p=null,ee=!1;const _e=`
  .${m} {
    position: fixed;
    bottom: 16px;
    right: 16px;
    z-index: 10000;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: none;
    background: #4c566a;
    color: white;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    transition: background 0.2s;
  }

  .${m}:hover { background: #5c6678; }

  .${m}.${T} { background: #bf616a; }
  .${m}.${T}:hover { background: #cf717a; }

  body.mainContentArea--dark .${m},
  body[data-theme="dark"] .${m},
  .darkMode .${m} {
    background: #5c6678;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
  }
  body.mainContentArea--dark .${m}:hover,
  body[data-theme="dark"] .${m}:hover,
  .darkMode .${m}:hover { background: #6c768a; }

  body.mainContentArea--dark .${m}.${T},
  body[data-theme="dark"] .${m}.${T},
  .darkMode .${m}.${T} { background: #bf616a; }
`;async function Ie(){var e;if(!ee){ee=!0;try{const t=document.querySelector('[data-testid="room-header_room-settings-button"]');if(!t)throw new Error("設定ボタンが見つかりません");t.click(),await w(300),(await se('[data-testid="room-header_room-settings_room-settings-menu"]',3e3)).click(),await w(500);const o=document.querySelectorAll('[role="tab"]');let a=null;for(const s of o)if(((e=s.textContent)==null?void 0:e.trim())==="ミュート"){a=s;break}if(!a)throw new Error("ミュートタブが見つかりません");a.click(),await w(300);const c=await se("#_roomSettingMute",3e3);c.click(),await w(200);const r=document.querySelector('[data-testid="room-setting-dialog_save-button"]');if(!r)throw new Error("保存ボタンが見つかりません");r.click();const i=c.checked;p&&(p.textContent=i?"🔇":"🔔",p.classList.toggle(T,i),p.title=i?"ミュート中（クリックで解除）":"ミュートする")}catch(t){console.error("[saikyo-cw] Mute error:",t);const n=document.querySelector('.dialogContainer button[aria-label="閉じる"]');n==null||n.click()}finally{ee=!1}}}function Me(){if(document.getElementById(Z))return;const e=document.createElement("style");e.id=Z,e.textContent=_e,document.head.appendChild(e)}const Le={config:{id:"mute-button",name:"Mute Button",description:"ワンクリックでチャットをミュート"},init(){Me(),p=document.createElement("button"),p.className=m,p.title="ミュートする",p.textContent="🔔",p.addEventListener("click",Ie),document.body.appendChild(p)},destroy(){var e;p==null||p.remove(),p=null,(e=document.getElementById(Z))==null||e.remove()}},Be={MESSAGE_ACTION_NAV:".messageActionNav"},te="https://www.chatwork.com/",de="quick-task",le="__scw_quick_task";async function ue(){return await ae(de)??{}}async function Ne(){var o;const e=await ue();if(e.myChatId)return e.myChatId;const t=prompt("taskを投稿するチャットのID(#!rid1234の1234の部分)");if(!t)throw new Error("Room ID is required");const n=((o=t.match(/\d+/))==null?void 0:o[0])??t;return await ye(de,{...e,myChatId:n}),n}function qe(e){return e.closest("._message")}function De(e){const t=e.getAttribute("data-rid")??"",n=e.getAttribute("data-mid")??"";return`${te}#!rid${t}-${n}`}function Pe(e){const t=e.querySelectorAll("pre span");return Array.from(t).map(n=>n.innerText).join(`
`)}async function Oe(e,t){var a;const n=(a=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value"))==null?void 0:a.set;n&&n.call(e,t),e.value=t;const o=e._valueTracker;o&&o.setValue("hello"),await w(200),e.dispatchEvent(new Event("input",{bubbles:!0}))}async function je(){try{const e=new MouseEvent("mouseover",{bubbles:!0,cancelable:!0});document.querySelectorAll("#_taskInputActive button").forEach(o=>o.dispatchEvent(e)),await w(200);const n=document.querySelector(".floatingComponentContainer .userIconImage");n==null||n.click()}catch(e){console.warn("[saikyo-cw] assignToSelf:",e)}await w(200)}async function Re(e,t){const n=De(e),o=t==="mychat-message"||t==="here-message",a=t==="here-url"||t==="here-message",c=o?`${n}
${Pe(e)}`:n;if(a){const d=e.getAttribute("data-rid")??"";location.href=`${te}#!rid${d}`}else{const d=await Ne();location.href=`${te}#!rid${d}`}await w(200);const r=document.querySelector("#_taskAddArea");r==null||r.click(),await w(200);const i=document.querySelector("#_taskInputActive textarea");i&&await Oe(i,c),a&&await je();const s=document.querySelector('button[data-testid="room-sub-column_room-task_add-button"]');s==null||s.click()}function He(e){if(e[le])return;e[le]=!0;const t=e.querySelectorAll(":scope > li"),n=Array.from(t).find(c=>{var r;return((r=c.textContent)==null?void 0:r.trim())==="タスク"});if(!n)return;const o=n.cloneNode(!0),a=o.querySelector(".actionLabel");a&&(a.textContent="my"),n.insertAdjacentElement("afterend",o),o.addEventListener("click",async()=>{const c=qe(e);if(!c)return;const i=(await ue()).mode??"mychat-url";try{await Re(c,i)}catch(s){console.error("[saikyo-cw] Quick Task error:",s)}})}let L=null;const ze={config:{id:"quick-task",name:"Quick Task",description:"メッセージにmy taskボタンを追加"},init(){L=R(Be.MESSAGE_ACTION_NAV,e=>{He(e)})},destroy(){L==null||L.disconnect(),L=null,document.querySelectorAll(".scw-quick-task__btn").forEach(e=>e.remove())}},ne="scw-mention-group-style",g="scw-mention-group-btn",A="scw-mention-group-dropdown",B="scw-mention-group-toast",S="quickMentionGroups",z="scw-mg-add-to-group",u="scw-mg-add-dropdown",Ge=`
  #${g} {
    display: inline-block;
    width: 32px;
    height: 32px;
    padding: 8px;
    border: none;
    border-radius: 4px;
    background: transparent;
    color: currentColor;
    cursor: pointer;
    vertical-align: middle;
    transition: background 0.15s;
  }
  #${g}:hover {
    background: rgba(0, 0, 0, 0.08);
  }
  #${g} svg {
    display: block;
    width: 16px;
    height: 16px;
    opacity: 0.7;
  }
  #${g}:hover svg {
    opacity: 1;
  }

  /* ダークモードでSVGが見えるように */
  body.mainContentArea--dark #${g},
  body[data-theme="dark"] #${g},
  .darkMode #${g} {
    color: #ccc;
  }
  body.mainContentArea--dark #${g}:hover,
  body[data-theme="dark"] #${g}:hover,
  .darkMode #${g}:hover {
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
  }

  #${A} {
    position: fixed;
    z-index: 100000;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05);
    padding: 6px;
    min-width: 180px;
    max-width: 260px;
    animation: scw-mg-in 0.12s ease-out;
  }
  @keyframes scw-mg-in {
    from { opacity: 0; transform: translateY(-4px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  .scw-mg-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 9px 14px;
    border: none;
    border-radius: 6px;
    background: none;
    cursor: pointer;
    font-size: 13px;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
    color: #333;
    transition: background 0.1s;
    text-align: left;
  }
  .scw-mg-item:hover { background: #e8f0fe; }
  .scw-mg-item-name { font-weight: 500; }
  .scw-mg-item-count {
    font-size: 11px;
    color: #888;
    background: #f0f0f0;
    padding: 2px 8px;
    border-radius: 10px;
    margin-left: 8px;
  }

  .scw-mg-empty {
    padding: 12px 14px 4px;
    font-size: 12px;
    color: #999;
    text-align: center;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
  }
  .scw-mg-hint {
    padding: 2px 14px 12px;
    font-size: 11px;
    color: #bbb;
    text-align: center;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
  }

  #${B} {
    position: fixed;
    bottom: 80px;
    left: 50%;
    transform: translateX(-50%) translateY(6px);
    z-index: 100001;
    background: #333;
    color: #fff;
    padding: 8px 18px;
    border-radius: 20px;
    font-size: 13px;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    opacity: 0;
    transition: all 0.25s ease;
    pointer-events: none;
    white-space: nowrap;
  }
  #${B}.scw-mg-toast-show {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }

  /* ダークモード */
  body.mainContentArea--dark #${A},
  body[data-theme="dark"] #${A},
  .darkMode #${A} {
    background: #2a2a2a;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.08);
  }
  body.mainContentArea--dark .scw-mg-item,
  body[data-theme="dark"] .scw-mg-item,
  .darkMode .scw-mg-item { color: #ddd; }
  body.mainContentArea--dark .scw-mg-item:hover,
  body[data-theme="dark"] .scw-mg-item:hover,
  .darkMode .scw-mg-item:hover { background: #333; }
  body.mainContentArea--dark .scw-mg-item-count,
  body[data-theme="dark"] .scw-mg-item-count,
  .darkMode .scw-mg-item-count { background: #444; color: #aaa; }

  /* プロフィールカード「グループに追加」ボタン */
  .${z} {
    padding: 6px 12px;
    border: 1px solid #4a90d9;
    border-radius: 6px;
    background: #4a90d9;
    color: white;
    font-size: 12px;
    cursor: pointer;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
    transition: background 0.15s;
    position: relative;
  }
  .${z}:hover { background: #357abd; }

  .${u} {
    position: absolute;
    bottom: 100%;
    left: 0;
    z-index: 100002;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    padding: 4px;
    min-width: 160px;
    margin-bottom: 4px;
    animation: scw-mg-in 0.12s ease-out;
  }
  .${u} button {
    display: block;
    width: 100%;
    padding: 8px 12px;
    border: none;
    border-radius: 6px;
    background: none;
    cursor: pointer;
    font-size: 12px;
    text-align: left;
    color: #333;
    font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", sans-serif;
  }
  .${u} button:hover { background: #e8f0fe; }
  .${u} .scw-mg-add-new {
    color: #4a90d9;
    border-top: 1px solid #eee;
    margin-top: 2px;
    padding-top: 8px;
  }

  body.mainContentArea--dark .${u},
  body[data-theme="dark"] .${u},
  .darkMode .${u} { background: #2a2a2a; }
  body.mainContentArea--dark .${u} button,
  body[data-theme="dark"] .${u} button,
  .darkMode .${u} button { color: #ddd; }
  body.mainContentArea--dark .${u} button:hover,
  body[data-theme="dark"] .${u} button:hover,
  .darkMode .${u} button:hover { background: #333; }
`;function Fe(e){return e.map(t=>`[To:${t.accountId}]${t.name}さん`).join(`
`)}function Ue(){return document.getElementById("_chatText")}function Ye(e){const t=Ue();if(!t){N("チャット入力欄が見つかりません");return}const n=Fe(e),o=t.value,a=t.selectionStart||0,c=t.selectionEnd||0,r=o.substring(0,a),i=o.substring(c),s=n+`
`;t.value=r+s+i;const d=a+s.length;t.selectionStart=d,t.selectionEnd=d,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.focus(),N(`${e.length}人にメンション追加`)}function N(e){const t=document.getElementById(B);t&&t.remove();const n=document.createElement("div");n.id=B,n.textContent=e,document.body.appendChild(n),requestAnimationFrame(()=>n.classList.add("scw-mg-toast-show")),setTimeout(()=>{n.classList.remove("scw-mg-toast-show"),setTimeout(()=>n.remove(),300)},2e3)}function G(){const e=document.getElementById(A);e&&e.remove()}function Ve(e){G(),chrome.storage.sync.get(S,t=>{const n=t[S]||[],o=document.createElement("div");if(o.id=A,n.length===0){const s=document.createElement("div");s.className="scw-mg-empty",s.textContent="グループ未登録",o.appendChild(s);const d=document.createElement("div");d.className="scw-mg-hint",d.textContent="拡張機能アイコンから設定してください",o.appendChild(d)}else for(const s of n){const d=document.createElement("button");d.className="scw-mg-item",d.innerHTML=`<span class="scw-mg-item-name">${s.name}</span><span class="scw-mg-item-count">${s.members.length}人</span>`,d.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation(),Ye(s.members),G()}),o.appendChild(d)}document.body.appendChild(o);const a=e.getBoundingClientRect(),c=o.getBoundingClientRect();let r=a.bottom+6,i=a.left;r+c.height>window.innerHeight-8&&(r=a.top-c.height-6),i+c.width>window.innerWidth-8&&(i=window.innerWidth-c.width-8),o.style.top=`${r}px`,o.style.left=`${i}px`,setTimeout(()=>{document.addEventListener("click",G,{once:!0})},10)})}function me(){if(document.getElementById(ne))return;const e=document.createElement("style");e.id=ne,e.textContent=Ge,document.head.appendChild(e)}function F(){if(document.getElementById(g))return;const e=document.getElementById("_to"),t=document.getElementById("_emoticon"),n=e||t;if(!n)return;const o=n.closest("._showDescription");if(!(o!=null&&o.parentElement))return;me();const a=document.createElement("div");a.className="_showDescription",a.style.display="block";const c=document.createElement("div");c.style.display="inline-block";const r=document.createElement("button");r.id=g,r.setAttribute("aria-label","クイックメンション：登録メンバーに一括メンション"),r.innerHTML=`<svg viewBox="0 0 10 10" width="16" height="16" fill="currentColor" aria-hidden="true">
    <circle cx="3.2" cy="2.5" r="1.5"/>
    <path d="M0.5 7.5C0.5 5.8 1.7 5 3.2 5s2.7.8 2.7 2.5v.5H0.5z"/>
    <circle cx="7" cy="2.5" r="1.3"/>
    <path d="M4.8 7.5C4.8 5.8 5.8 5 7 5s2.2.8 2.2 2.5v.5H4.8z"/>
  </svg>`,r.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),Ve(r)}),c.appendChild(r),a.appendChild(c),o.parentElement.insertBefore(a,o.nextSibling)}function We(e){var s,d,y,E,C,v;const t=e.getAttribute("data-aid");if(!t)return;const n=e.closest("div[data-aid]")??((y=(d=(s=e.parentElement)==null?void 0:s.parentElement)==null?void 0:d.parentElement)==null?void 0:y.parentElement);if(!n||n.querySelector(`.${z}`))return;const o=n.querySelector('[data-testid="profile-popup_user-name"] span[class*="_nameAid"]'),a=((E=o==null?void 0:o.textContent)==null?void 0:E.trim())??"";if(!a)return;const c=(v=(C=e.parentElement)==null?void 0:C.parentElement)==null?void 0:v.parentElement;if(!c)return;me();const r=document.createElement("div");r.style.cssText="display: inline-block; position: relative;";const i=document.createElement("button");i.className=z,i.textContent="グループに追加",i.addEventListener("click",h=>{h.preventDefault(),h.stopPropagation(),document.querySelectorAll(`.${u}`).forEach(re=>re.remove()),chrome.storage.sync.get(S,re=>{const P=re[S]||[],k=document.createElement("div");if(k.className=u,P.length===0){const b=document.createElement("button");b.className="scw-mg-add-new",b.textContent="新規グループを作成",b.addEventListener("click",()=>{const l=prompt("グループ名を入力");if(!l)return;const O={name:l,members:[{accountId:t,name:a}]};chrome.storage.sync.set({[S]:[O]},()=>{N(`「${l}」に ${a} を追加しました`),k.remove()})}),k.appendChild(b)}else{for(const l of P){const O=l.members.some(nt=>nt.accountId===t),j=document.createElement("button");j.textContent=O?`${l.name} (追加済み)`:l.name,O&&(j.style.color="#999",j.style.cursor="default"),j.addEventListener("click",()=>{O||(l.members.push({accountId:t,name:a}),chrome.storage.sync.set({[S]:P},()=>{N(`「${l.name}」に ${a} を追加しました`),k.remove()}))}),k.appendChild(j)}const b=document.createElement("button");b.className="scw-mg-add-new",b.textContent="+ 新規グループに追加",b.addEventListener("click",()=>{const l=prompt("グループ名を入力");l&&(P.push({name:l,members:[{accountId:t,name:a}]}),chrome.storage.sync.set({[S]:P},()=>{N(`「${l}」に ${a} を追加しました`),k.remove()}))}),k.appendChild(b)}r.appendChild(k),setTimeout(()=>{const b=l=>{!k.contains(l.target)&&l.target!==i&&(k.remove(),document.removeEventListener("click",b))};document.addEventListener("click",b)},10)})}),r.appendChild(i),c.appendChild(r)}function Ke(){var n,o;const e=document.getElementById(g),t=e==null?void 0:e.closest("._showDescription");t==null||t.remove(),G(),(n=document.getElementById(B))==null||n.remove(),(o=document.getElementById(ne))==null||o.remove()}let _=null,q=null;const Xe={config:{id:"mention-group",name:"Mention Group",description:"グループメンションをワンクリックで挿入"},init(){_=new MutationObserver(()=>{document.getElementById("scw-mention-group-btn")||F()}),_.observe(document.body,{childList:!0,subtree:!0}),F(),setTimeout(F,1e3),setTimeout(F,3e3),q=R('[data-testid="profile-popup_profile-button"]',e=>{We(e)})},destroy(){_==null||_.disconnect(),_=null,q==null||q.disconnect(),q=null,Ke()}},U="scw-reaction-copy",f="scw-reaction-copy__button",x="scw-reaction-copy__button--to",oe="scw-reaction-copy-style";let D=null;const Qe=`
  .${U} {
    display: flex;
    gap: 4px;
    margin-bottom: 4px;
  }

  .${f} {
    padding: 4px;
    font-size: 12px;
    background-color: #eee;
    border: 1px solid #ccc;
    border-radius: 4px;
    cursor: pointer;
    color: #333;
  }

  .${f}:hover {
    background-color: #ddd;
  }

  .${x} {
    background-color: #e0f0ff;
    border-color: #a8d4f0;
    color: #1a6fa8;
  }

  .${x}:hover {
    background-color: #cce4f7;
  }

  /* ダークモード */
  body.mainContentArea--dark .${f},
  body[data-theme="dark"] .${f},
  .darkMode .${f} {
    background-color: #3a3a3a;
    border-color: #555;
    color: #ddd;
  }

  body.mainContentArea--dark .${f}:hover,
  body[data-theme="dark"] .${f}:hover,
  .darkMode .${f}:hover {
    background-color: #4a4a4a;
  }

  body.mainContentArea--dark .${x},
  body[data-theme="dark"] .${x},
  .darkMode .${x} {
    background-color: #1a3a50;
    border-color: #2a5a7a;
    color: #8ac4ea;
  }

  body.mainContentArea--dark .${x}:hover,
  body[data-theme="dark"] .${x}:hover,
  .darkMode .${x}:hover {
    background-color: #224a62;
  }

  @media (prefers-color-scheme: dark) {
    body.mainContentArea--dark .${f},
    body[data-theme="dark"] .${f},
    .darkMode .${f} {
      background-color: #3a3a3a;
      border-color: #555;
      color: #ddd;
    }
  }
`;function pe(e){const t=e.querySelectorAll("li.reactionUserListTooltip__item");return Array.from(t).map(n=>{var c,r,i;let o=((r=(c=n.querySelector(".reactionUserListTooltip__userName"))==null?void 0:c.textContent)==null?void 0:r.trim())??"";o=o.replace(/さん$/,"");const a=n.getAttribute("data-cwui-lt-value")??((i=n.querySelector("img[data-aid]"))==null?void 0:i.getAttribute("data-aid"))??null;return{name:o,accountId:a}})}function ge(e,t){const n=e.textContent;navigator.clipboard.writeText(t).then(()=>{e.textContent="コピー済み",setTimeout(()=>{e.textContent=n},1e3)})}function Je(e){if(e.querySelector(`.${U}`))return;const t=document.createElement("div");t.className=U;const n=document.createElement("button");n.className=f,n.textContent="コピー",n.addEventListener("click",()=>{const c=pe(e).map(r=>r.name).filter(Boolean).join(`
`);ge(n,c)});const o=document.createElement("button");o.className=`${f} ${x}`,o.textContent="TO付きコピー",o.addEventListener("click",()=>{const c=pe(e).filter(r=>r.name).map(r=>r.accountId?`[To:${r.accountId}]${r.name}さん`:r.name).join(`
`);ge(o,c)}),t.appendChild(n),t.appendChild(o),e.prepend(t)}function Ze(){if(document.getElementById(oe))return;const e=document.createElement("style");e.id=oe,e.textContent=Qe,document.head.appendChild(e)}function et(){var e;(e=document.getElementById(oe))==null||e.remove()}const fe=[Ae,Le,ze,Xe,{config:{id:"reaction-copy",name:"Reaction Copy",description:"リアクションしたユーザー一覧をコピー（TO付きも対応）"},init(){Ze(),D=R("#_reactionUserList",e=>{Je(e)})},destroy(){D==null||D.disconnect(),D=null,et(),document.querySelectorAll(`.${U}`).forEach(e=>e.remove())}}],Y=new Map;async function tt(){var t;const e=await be();for(const n of fe)(((t=e[n.config.id])==null?void 0:t.enabled)??!0)&&(n.init(),Y.set(n.config.id,n));chrome.storage.onChanged.addListener((n,o)=>{var a;if(o==="sync")for(const c of fe){const r=he(c.config.id),i=n[r];if(!i)continue;const s=Y.has(c.config.id),d=((a=i.newValue)==null?void 0:a.enabled)??!0;s&&!d?(c.destroy(),Y.delete(c.config.id)):!s&&d&&(c.init(),Y.set(c.config.id,c))}})}tt()})();
